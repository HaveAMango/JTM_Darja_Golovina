package jtm.activity07;

public class AnimalTests1 extends AnimalTests {
}