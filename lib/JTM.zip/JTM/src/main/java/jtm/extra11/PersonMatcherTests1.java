package jtm.extra11;

public class PersonMatcherTests1 extends PersonMatcherTests {
	
}
