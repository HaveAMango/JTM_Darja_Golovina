package jtm.activity13;

public class DatabaseTest1 extends DatabaseTest {
}
