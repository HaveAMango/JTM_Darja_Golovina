package jtm.activity05;

public class EncapsulationTests1 extends EncapsulationTests {
}