package jtm.extra01;

public class GetOneTest1 extends GetOneTest {

}
