package jtm.extra01;

public class ZodiacTest1 extends ZodiacTest {
}
