package jtm.extra04;

public class JsonCarsTest1 extends JsonCarsTest {

}
