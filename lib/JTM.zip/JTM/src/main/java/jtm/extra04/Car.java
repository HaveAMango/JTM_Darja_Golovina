package jtm.extra04;

public class Car {

	private String model;
	private Integer year;
	private String color;
	private Float price;

	// TODO #1 generate public constructor which takes all properties of an
	// object as parameters

	// TODO #2 generate public getters of all object properties
}
