package jtm.activity09;

public class OrdersTests1 extends OrdersTests {
}
