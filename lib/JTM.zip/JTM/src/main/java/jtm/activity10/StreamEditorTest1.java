package jtm.activity10;

public class StreamEditorTest1 extends StreamEditorTest {
}
