package jtm.activity03;

public class BlackKnightTest1 extends BlackKnightTest {
}
