package jtm.activity03;

public class RandomPersonTest1 extends RandomPersonTest {
}
