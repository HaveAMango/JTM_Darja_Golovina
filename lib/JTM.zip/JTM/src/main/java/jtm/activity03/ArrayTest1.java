package jtm.activity03;

public class ArrayTest1 extends ArrayTest {
}