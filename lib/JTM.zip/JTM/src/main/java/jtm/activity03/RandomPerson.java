package jtm.activity03;

public class RandomPerson {

	// TODO Create _private_ structure of random person to store values:
	// name as String,
	// age as int,
	// weight as float,
	// isFemale as boolean;
	// smile as char
	// HINT: use Alt+Shift+A to switch to Block selection (multi-line cursor)
	// to edit list of all properties at once

	// TODO Select menu "Source — Generate Getters and Setters..." then select
	// all properties and generate _public_ getters and setters for all of them
}
