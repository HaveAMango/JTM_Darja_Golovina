package jtm.extra09;

public class GameTest1 extends GameTest {
}