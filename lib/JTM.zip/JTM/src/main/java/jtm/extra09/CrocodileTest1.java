package jtm.extra09;

public class CrocodileTest1 extends CrocodileTest {
}