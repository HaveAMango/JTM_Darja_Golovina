package jtm.extra06;

public class RegExTest1 extends RegExTest {
}