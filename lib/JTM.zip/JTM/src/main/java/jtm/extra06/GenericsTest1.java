package jtm.extra06;

public class GenericsTest1 extends GenericsTest {
}