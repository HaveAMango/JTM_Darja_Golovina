package jtm.extra06;

public class HolidayTest1 extends HolidayTest {
}