package jtm.activity08;

public class SimpleCalcTests1 extends SimpleCalcTests {
}