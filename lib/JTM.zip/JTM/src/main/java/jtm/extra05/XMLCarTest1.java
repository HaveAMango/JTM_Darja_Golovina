package jtm.extra05;

public class XMLCarTest1 extends XMLCarsTest {
}