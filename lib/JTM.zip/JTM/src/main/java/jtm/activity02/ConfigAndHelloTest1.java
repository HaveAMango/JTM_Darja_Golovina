package jtm.activity02;

public class ConfigAndHelloTest1 extends ConfigAndHelloTest {
}
