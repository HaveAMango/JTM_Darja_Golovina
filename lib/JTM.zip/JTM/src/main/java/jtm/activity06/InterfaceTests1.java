package jtm.activity06;

public class InterfaceTests1 extends InterfaceTests {
}