package jtm.extra08;

public class InvoiceManagerTest1 extends InvoiceManagerTest {

}
