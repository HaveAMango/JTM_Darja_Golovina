package jtm.extra07;

import jtm.extra07.ChatClientTest;

public class ChatClientTest1 extends ChatClientTest {

}
