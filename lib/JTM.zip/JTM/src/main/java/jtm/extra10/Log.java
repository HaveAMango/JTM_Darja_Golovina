package jtm.extra10;

import org.apache.log4j.Logger;

public class Log {

	/*- TODO #1
	 * Implement static methods for Log class to write trace, debug, info, warn, error and fatal messages
	 * Note, that this logger should have classpath jtm.extra10.Log
	 */


	/*- TODO #2
	 * Implement public static Logger getLoger() method,
	 * which returns reference to the logger used for logging
	 */


	public static class ExtLog extends Log {
		/*- TODO #2
		 * Implement internal class ExtLog which allows to write into log trace, debug, info, warn, error and fatal messages
		 * Note, that this logger should have classpath jtm.extra10.Log$ExtLog
		 */
	}

}
