package jtm.extra10;

public class LogTest1 extends LogTest {

}
