package jtm.activity04;

public class TrafficManagementTest1 extends TrafficManagementTest {
}