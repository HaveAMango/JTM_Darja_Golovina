package jtm.extra12;

public class JNIClassTest1 extends JNIClassTest {

}
