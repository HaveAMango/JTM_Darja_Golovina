package jtm.activity12;

public class ChatServerTest1 extends ChatServerTest {
}