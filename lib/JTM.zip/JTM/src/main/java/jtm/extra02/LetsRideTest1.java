package jtm.extra02;

public class LetsRideTest1 extends LetsRideTest {

}
