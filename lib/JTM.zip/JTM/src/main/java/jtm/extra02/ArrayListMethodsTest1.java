package jtm.extra02;

public class ArrayListMethodsTest1 extends ArrayListMethodsTest {

}
