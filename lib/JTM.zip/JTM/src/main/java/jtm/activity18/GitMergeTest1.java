package jtm.activity18;

public class GitMergeTest1 extends GitMergeTest {

}
