package jtm.extra03;

public class PracticalNumbersTest1 extends PracticalNumbersTest {
}